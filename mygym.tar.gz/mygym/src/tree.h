enum {
ID2,
ADHERANT2,
KINE2,
COLUMNS2
};
void afficher1(GtkWidget*liste);
typedef struct fiche{
  char adherant [20];
  char ID[5];
  char etat[20];
}fiche;
