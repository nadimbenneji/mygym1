#include <stdio.h>
#include <stdlib.h>
#include "mygym.h"
#include <gtk/gtk.h>
enum {
ID,
ADHERANT,
KINE,
JOUR,
MOIS,
ANNEE,
HOUR,
COLUMNS
};
void ajouter(seance s){
  FILE*f;
f=fopen("/home/nadim/Desktop/cure.txt","a+");
     if(f!=NULL) {

       fprintf(f,"%s %s %s %s-%s-%s %s\n",s.ID,s.adherant,s.kine,s.jour,s.mois,s.annee,s.hour);
       fclose(f); };
}
void afficher(GtkListeView *liste){
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char adherant[20];
char kine[20];
char jour[3];char mois[3];char annee[5];char id[5];
char hour[50];
store=NULL;
FILE*f;
store=gtk_tree_view_get_model(liste);
if(store==NULL){
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" id",renderer,"text",NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" adherant",renderer,"text",NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" kine",renderer,"text",NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" mois",renderer,"text",NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" annee",renderer,"text",NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" hour",renderer,"text",NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
store=gtk_list_store_new(column, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("/home/nadim/Desktop/cure.txt","r");
if(f!=NULL){
  f=fopen("/home/nadim/Desktop/cure.txt","a+");
  while(fscanf(f,"%s %s %s %s-%s-%s %s\n",ID,adherant,kine,jour,mois,annee,hour)!=EOF){
  gtk_list_store_append(store,&iter);
  gtk_list_store_set(store,&iter,ID,id,ADHERANT,adherant,KINE,kine,JOUR,jour,MOIS,mois,ANNEE,annee,HOUR,hour,-1);
    }
    fclose(f);
    gtk_tree_view_set_model(GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
    g_object_unref(store);
  }
}
}
