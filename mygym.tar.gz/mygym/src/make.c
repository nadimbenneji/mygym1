#include <stdio.h>
#include <stdlib.h>
void main 
{
FILE*f;
f=fopen("/home/nadim/Desktop/zebi.txt","a+");
remove("/home/nadim/Desktop/zebi.txt");
}



