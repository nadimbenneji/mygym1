#include <gtk/gtk.h>
typedef struct{
char adherant[20];
char kine[20];
char jour[3];char mois[3];char annee[5];char ID[5];
char hour[50];
}seance;
void ajouter(seance s);
void afficher(GtkListeView*liste);
