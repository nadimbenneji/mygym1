#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif


#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include <stdio.h>
#include "login.h"
/*#include "tree.h"*/
/*#include "mygym.h"*/
typedef struct{
char adherant[20];
char kine[20];
char jour[3];char mois[3];char annee[5];char ID[5];
char hour[50];
}seance;
enum {
ID2,
ADHERANT2,
ETAT2,
COLUMNS2
};
void afficher1(GtkWidget*liste);
typedef struct fiche{
  char adherant [20];
  char ID[5];
  char etat[20];
}fiche;


void ajouter(seance s);
void afficher(GtkWidget*liste);
void supprimer(char id[],int n);






void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  int n=150,check = -1;
    char b[20]="bonjour ";
    char c[50]="wrong user id or password";
    GtkWidget *input1;
    GtkWidget *input2;
    GtkWidget *output1;
    GtkWidget *output2;
    GtkWidget *output3;
    GtkWidget *output4;
    GtkWidget *output5;
    GtkWidget *output6;
    GtkWidget *output7;
    GtkWidget *window2;
    GtkWidget *window3;
    GtkWidget *window4;
    GtkWidget *window5;
    GtkWidget *window6;
    GtkWidget *window7;
    GtkWidget *window1;
    window2=create_window2();
    window3=create_window3();
    window4=create_window4();
    window5=create_window5();
    window6=create_window6();
    window7=create_window7();
    window1=lookup_widget(objet_graphique,"window1");
    input1=lookup_widget(objet_graphique, "entry1");
    input2=lookup_widget(objet_graphique, "entry2");
    output1=lookup_widget(objet_graphique, "label4");

    char nom[20];
    strcpy(nom,gtk_entry_get_text(GTK_ENTRY(input1)));
    char pass[20];
    strcpy(pass,gtk_entry_get_text(GTK_ENTRY(input2)));
    check = check_user(nom,pass,n);
    if (check!=-1){
      gtk_widget_hide(window1);
      switch (check) {
        case 1 :{strcat(b,"admin");
        gtk_widget_show(window2);
        output2=lookup_widget(window2, "label5");
        gtk_label_set_text(GTK_LABEL(output2),b);
      break ;};
        case 2 :{strcat(b,"kine");
        gtk_widget_show(window3);
        output3=lookup_widget(window3, "label6");
        gtk_label_set_text(GTK_LABEL(output3),b);
      break ;};
        case 3 :{strcat(b,"adherant");
        gtk_widget_show(window4);
        output4=lookup_widget(window4, "label7");
        gtk_label_set_text(GTK_LABEL(output4),b);
      break ;};
        case 4 :{strcat(b,"coach");
        gtk_widget_show(window5);
        output5=lookup_widget(window5, "label8");
        gtk_label_set_text(GTK_LABEL(output5),b);
      break ;};
        case 5 :{strcat(b,"docteur");
        gtk_widget_show(window6);
        output6=lookup_widget(window6, "label9");
        gtk_label_set_text(GTK_LABEL(output6),b);
      break ;};
        default : {strcat(b,"dietiticien");
        gtk_widget_show(window7);
        output7=lookup_widget(window7, "label10");
        gtk_label_set_text(GTK_LABEL(output7),b);
      break ;};
      }
      gtk_label_set_text(GTK_LABEL(output1),"");

    }else{
    gtk_label_set_text(GTK_LABEL(output1),c);
    }

}

void
on_button1_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
gtk_main_quit();
}

void
on_button6_clicked                     (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *window3;
  GtkWidget *window1;
  window3=lookup_widget(objet_graphique,"window3");
  gtk_widget_hide(window3);
  window1=create_window1();
  gtk_widget_show(window1);

}


void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *window3 ;
  GtkWidget *window8 ;
  GtkWidget *treeview2;
  window8=create_window8();
  window3=lookup_widget(objet_graphique,"window3");
  gtk_widget_hide(window3);
  gtk_widget_show(window8);
  treeview2=lookup_widget(window8,"treeview2");
  afficher(treeview2);


}

void
on_button10_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *window8;
  GtkWidget *window1;
  window1=create_window1();
  window8=lookup_widget(objet_graphique,"window8");
  gtk_widget_hide(window8);
  gtk_widget_show(window1);
}


void
on_button11_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *window8;
  GtkWidget *window3;
  window3=create_window3();

  window8=lookup_widget(objet_graphique,"window8");
  gtk_widget_hide(window8);
  gtk_widget_show(window3);
}

void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input ;
GtkWidget *treeview2;
GtkWidget *output;
GtkWidget *window8 ;
char c[]="session deleted";
output=lookup_widget(objet_graphique,"label24");
window8=lookup_widget(objet_graphique,"window8");
int n=5;
char id[5];
input=lookup_widget(objet_graphique,"entry7");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
supprimer(id,n);
treeview2=lookup_widget(objet_graphique,"treeview2");
afficher(treeview2);
gtk_label_set_text(GTK_LABEL(output),c);

}
void supprimer(char id[],int n){
  seance s ;
    FILE*f;
  FILE*f1;
  f=fopen("cure.txt","a+");
  f1=fopen("cures.txt","a+");
  if(f!=NULL) {
    while(fscanf(f,"%s %s %s %s %s %s %s\n",s.ID,s.adherant,s.kine,s.jour,s.mois,s.annee,s.hour)!=EOF){
      if (strcmp(id,s.ID)!=0){
          fprintf(f1,"%s %s %s %s %s %s %s\n",s.ID,s.adherant,s.kine,s.jour,s.mois,s.annee,s.hour);
        }
  }
}
fclose(f);
fclose(f1);
remove("cure.txt");
rename("cures.txt","cure.txt");
}
void modifier(seance s){
  seance c ;
  FILE*f;
  FILE*f1;
  f=fopen("cure.txt","a+");
  f1=fopen("cures.txt","a+");
  if(f!=NULL){
    while(fscanf(f,"%s %s %s %s %s %s %s\n",c.ID,c.adherant,c.kine,c.jour,c.mois,c.annee,c.hour)!=EOF){
      if(strcmp(c.ID,s.ID)==0) {
        fprintf(f1,"%s %s %s %s %s %s %s\n",s.ID,s.adherant,s.kine,s.jour,s.mois,s.annee,s.hour);
      }
      else fprintf(f1,"%s %s %s %s %s %s %s\n",c.ID,c.adherant,c.kine,c.jour,c.mois,c.annee,c.hour);
    }
  }
  fclose(f);
fclose(f1);
remove("cure.txt");
rename("cures.txt","cure.txt");
}




void
on_button8_clicked                     (GtkWidget      *objet_graphique,

                                      gpointer         user_data)
{ char id[20];
seance s ;
FILE*f;
  GtkWidget *input ;
  GtkWidget *output1;
  GtkWidget *output2;
  GtkWidget *output3;
  GtkWidget *output4;
  GtkWidget *output5;
  GtkWidget *output6;
  GtkWidget *output7;
  GtkWidget *window11;
  GtkWidget *window8;
  input=lookup_widget(objet_graphique,"entry6");
  strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
  window11=create_window11();
  window8=lookup_widget(objet_graphique,"window8");
  gtk_widget_hide(window8);
  gtk_widget_show(window11);
output1=lookup_widget(window11,"entry8");
output2=lookup_widget(window11,"entry9");
output3=lookup_widget(window11,"spinbutton4");
output4=lookup_widget(window11,"spinbutton5");
output5=lookup_widget(window11,"spinbutton6");
output6=lookup_widget(window11,"comboboxentry2");
output7=lookup_widget(window11,"entry10");
f=fopen("cure.txt","a+");
if(f!=NULL){
while(fscanf(f,"%s %s %s %s %s %s %s\n",s.ID,s.adherant,s.kine,s.jour,s.mois,s.annee,s.hour)!=EOF){
      if(strcmp(id,s.ID)==0) {
        gtk_entry_set_text(GTK_ENTRY(output1),s.adherant);
        gtk_entry_set_text(GTK_ENTRY(output2),s.kine);
        gtk_entry_set_text(GTK_ENTRY(output3),s.jour);
        gtk_entry_set_text(GTK_ENTRY(output4),s.mois);
        gtk_entry_set_text(GTK_ENTRY(output5),s.annee);
        gtk_entry_set_text(GTK_ENTRY(output6),s.hour);
        gtk_entry_set_text(GTK_ENTRY(output7),s.ID);
      }
    }
    fclose(f);
}




}


void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window10;
GtkWidget *window8;
window10=create_window10();

window8=lookup_widget(objet_graphique,"window8");
gtk_widget_hide(window8);
gtk_widget_show(window10);

}

void
on_button13_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *window10;
  GtkWidget *window8;
  GtkWidget *treeview2;
  window8=create_window8();
  window10=lookup_widget(objet_graphique,"window10");
  gtk_widget_hide(window10);
  gtk_widget_show(window8);
  treeview2=lookup_widget(window8,"treeview2");
  afficher(treeview2);


}


void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

    GtkWidget *input1 ;
    GtkWidget *input2 ;
    GtkWidget *input3 ;
    GtkWidget *input4;
    GtkWidget *input5;
    GtkWidget *input6;
    GtkWidget *input7;
    GtkWidget *output;



    FILE*f;
    char c[]="session saved";
    seance s;
    input1=lookup_widget(objet_graphique,"entry3");
    input2=lookup_widget(objet_graphique,"entry4");
    input3=lookup_widget(objet_graphique,"spinbutton1");
    input4=lookup_widget(objet_graphique,"spinbutton2");
    input5=lookup_widget(objet_graphique,"spinbutton3");
    input6=lookup_widget(objet_graphique,"comboboxentry1");
    output=lookup_widget(objet_graphique,"label15");
    input7=lookup_widget(objet_graphique,"entry5");
    strcpy(s.adherant,gtk_entry_get_text(GTK_ENTRY(input1)));
    strcpy(s.kine,gtk_entry_get_text(GTK_ENTRY(input2)));
    strcpy(s.jour,gtk_entry_get_text(GTK_ENTRY(input3)));
    strcpy(s.mois,gtk_entry_get_text(GTK_ENTRY(input4)));
    strcpy(s.annee,gtk_entry_get_text(GTK_ENTRY(input5)));
    strcpy(s.hour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));
    strcpy(s.ID,gtk_entry_get_text(GTK_ENTRY(input7)));
    ajouter(s);
    gtk_label_set_text(GTK_LABEL(output),c);


   }


void
on_button14_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *window8 ;
  GtkWidget *window9;
  GtkWidget *treeview1;
  window9=create_window9();
  window8=lookup_widget(objet_graphique,"window8");
  gtk_widget_hide(window8);
  gtk_widget_show(window9);
  treeview1=lookup_widget(window9,"treeview1");
  afficher(treeview1);

  }
enum {
ID,
ADHERANT,
KINE,
JOUR,
MOIS,
ANNEE,
HOUR,
ETAT,
COLUMNS
};
void ajouter(seance s){
  FILE*f;
f=fopen("cure.txt","a");
     if(f!=NULL) {

       fprintf(f,"%s %s %s %s %s %s %s\n",s.ID,s.adherant,s.kine,s.jour,s.mois,s.annee,s.hour);
       fclose(f); };
}
void afficher(GtkWidget*liste){
GtkCellRenderer*renderer;
GtkTreeViewColumn*column;
GtkTreeIter iter;
GtkListStore*store;
seance s ;
FILE*f;
store=gtk_tree_view_get_model(liste);
if(store==NULL){
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("ID",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("adherant",renderer,"text",ADHERANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("kine",renderer,"text",KINE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("hour",renderer,"text",HOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
}

f=fopen("cure.txt","a+");
if(f!=NULL){
  while(fscanf(f,"%s %s %s %s %s %s %s\n",s.ID,s.adherant,s.kine,s.jour,s.mois,s.annee,s.hour)!=EOF){
  gtk_list_store_append(store,&iter);
  gtk_list_store_set(store,&iter,ID,s.ID,ADHERANT,s.adherant,KINE,s.kine,JOUR,s.jour,MOIS,s.mois,ANNEE,s.annee,HOUR,s.hour,-1);
    }
    fclose(f);
    gtk_tree_view_set_model(GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
    g_object_unref(store);
  }

}

void
on_button15_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *window9;
  GtkWidget *window8;
  window8=create_window8();
  window9=lookup_widget(objet_graphique,"window9");
  gtk_widget_hide(window9);
  gtk_widget_show(window8);
}

void
on_button16_clicked                    (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{ GtkWidget *input1;
  GtkWidget *input2;
  GtkWidget *input3;
  GtkWidget *input4;
  GtkWidget *input5;
  GtkWidget *input6;
  GtkWidget *input7;
  FILE*f;
  GtkWidget *output;
  char c[]="session updated";
  output=lookup_widget(objet_graphique,"label25");
    seance s;
    input1=lookup_widget(objet_graphique,"entry8");
    input2=lookup_widget(objet_graphique,"entry9");
    input3=lookup_widget(objet_graphique,"spinbutton4");
    input4=lookup_widget(objet_graphique,"spinbutton5");
    input5=lookup_widget(objet_graphique,"spinbutton6");
    input6=lookup_widget(objet_graphique,"comboboxentry2");
    input7=lookup_widget(objet_graphique,"entry10");
    strcpy(s.adherant,gtk_entry_get_text(GTK_ENTRY(input1)));
    strcpy(s.kine,gtk_entry_get_text(GTK_ENTRY(input2)));
    strcpy(s.jour,gtk_entry_get_text(GTK_ENTRY(input3)));
    strcpy(s.mois,gtk_entry_get_text(GTK_ENTRY(input4)));
    strcpy(s.annee,gtk_entry_get_text(GTK_ENTRY(input5)));
    strcpy(s.hour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));
    strcpy(s.ID,gtk_entry_get_text(GTK_ENTRY(input7)));
    modifier(s);
    gtk_label_set_text(GTK_LABEL(output),c);


}


void
on_button17_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *window11;
  GtkWidget *window8;
  window8=create_window8();
  window11=lookup_widget(objet_graphique,"window11");
  gtk_widget_hide(window11);
  gtk_widget_show(window8);
  GtkWidget *treeview2;
  treeview2=lookup_widget(window8,"treeview2");
  afficher(treeview2);
}

void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *window3 ;
  GtkWidget *window12;
  GtkWidget *treeview3;
  window3=lookup_widget(objet_graphique,"window3");
  gtk_widget_hide(window3);
  window12=lookup_widget(objet_graphique,"window12");
  window12=create_window12();
  gtk_widget_show(window12);
  treeview3=lookup_widget(window12,"treeview3");
  afficher1(treeview3);
}



void
on_button18_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *window12;
  GtkWidget *window3;
  window3=create_window3();
  window12=lookup_widget(objet_graphique,"window12");
  gtk_widget_hide(window12);
  gtk_widget_show(window3);

}
void afficher1(GtkWidget*liste){
GtkCellRenderer*renderer;
GtkTreeViewColumn*column;
GtkTreeIter iter;
GtkListStore*store;
fiche s ;
FILE*f;
store=gtk_tree_view_get_model(liste);
if(store==NULL){
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("ID",renderer,"text",ID2,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("adherant",renderer,"text",ADHERANT2,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("etat",renderer,"text",ETAT2,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
store=gtk_list_store_new(COLUMNS2,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
};
f=fopen("fiche.txt","a+");
if(f!=NULL){
  while(fscanf(f,"%s %s %s\n",s.ID,s.adherant,s.etat)!=EOF){
  gtk_list_store_append(store,&iter);
  gtk_list_store_set(store,&iter,ID2,s.ID,ADHERANT2,s.adherant,ETAT2,s.etat,-1);
    }
    fclose(f);
    gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL(store));
    g_object_unref(store);
  }

}
