int check_user(char inpt_login[], char inpt_mdp[],int n);
